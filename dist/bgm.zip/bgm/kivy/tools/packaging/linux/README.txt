Package hosting:
	PPA stable			https://launchpad.net/~kivy-team/+archive/kivy
	PPA daily			https://launchpad.net/~kivy-team/+archive/kivy-daily
	
	OBS stable (not maintained)	https://build.opensuse.org/project/show?project=home%3Athopiekar%3Akivy
	OBS testing (not maintained)	https://build.opensuse.org/project/show?project=home%3Athopiekar%3Akivy-testing

	COBS (not maintained)		https://build.pub.meego.com/project/show?project=home%3Athopiekar%3Akivy

PPA recipes:
	stable		https://code.launchpad.net/~thopiekar/+recipe/kivy-stable
	daily		https://code.launchpad.net/~thopiekar/+recipe/kivy-daily

Related instructions:
	http://kivy.org/docs/installation/installation-linux.html
