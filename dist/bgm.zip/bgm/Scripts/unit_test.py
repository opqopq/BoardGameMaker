__author__ = 'HO.OPOYEN'

def test_print():
    prepare_pdf(stack, 'test.pdf')

test_print()