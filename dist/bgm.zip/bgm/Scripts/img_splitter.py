__author__ = 'opq'

if not file_selector.selection:
    alert('Choose file first')
else:
    img_path = file_selector.selection[0]